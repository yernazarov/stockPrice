//
//  MyQuoteCell.swift
//  stockPrice
//
//  Created by Zhandos Yernazarov on 6/13/20.
//  Copyright © 2020 Zhandos Yernazarov. All rights reserved.
//

import UIKit

class MyQuoteCell: UITableViewCell{
    
    @IBOutlet weak var mySymbol: UILabel!
    
    @IBOutlet weak var myShortName: UILabel!
    @IBOutlet weak var myRegularMarketPrice: UILabel!
    
    @IBOutlet weak var myRMCP: UILabel!
    
    @IBOutlet weak var myRMC: UILabel!
    
}
