//
//  MyStocksViewController.swift
//  stockPrice
//
//  Created by Zhandos Yernazarov on 6/13/20.
//  Copyright © 2020 Zhandos Yernazarov. All rights reserved.
//

import UIKit

class MyStocksViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var stockInfo: UILabel!
    var results = [Result]()
    var totalQuotes: Int = 0
    var totalRMP = 0.0
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        NotificationCenter.default.addObserver(self, selector: #selector(notificationReceivedd), name: Notification.Name("appendToPortfolio"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(notification2Receivedd), name: Notification.Name("deleteFromPortfolio"), object: nil)
    }
    @objc func notificationReceivedd(notification: Notification){
        let temp = notification.object as! Result
        for result in results{
            if result.symbol == temp.symbol{
                print("Already in MyStocks")
                return
            }
        }
        totalQuotes += 1
        totalRMP += temp.regularMarketPrice
        results.append(temp)
        tableView.reloadData()
        stockInfo.text = "You have \(totalQuotes) quotes in your portfolio. Total market price of the quotes is: \(totalRMP)"
        stockInfo.reloadInputViews()
    }
    @objc func notification2Receivedd(notification: Notification){
        let temp2 = notification.object as! Result
        var i:Int = 0
        for result in results{
            if result.symbol == temp2.symbol{
                results.remove(at: i)
                totalQuotes -= 1
                totalRMP -= temp2.regularMarketPrice
                tableView.reloadData()
                stockInfo.text = "You have \(totalQuotes) quotes in your portfolio. Total market price of the quotes is: \(totalRMP)"
                stockInfo.reloadInputViews()
                return
            }
            i+=1
        }
    }
    
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return results.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyQuoteCell", for: indexPath) as! MyQuoteCell
        let quote = results[indexPath.row]
        cell.mySymbol?.text = quote.symbol
        cell.myShortName?.text = quote.shortName
        cell.myRMC?.text = String(format: "%.2f", quote.regularMarketChange )
        cell.myRegularMarketPrice?.text = String(format: "%.2f $", quote.regularMarketPrice )
            //        "\(quote?.regularMarketPrice ?? 0)$"
        cell.myRMCP?.text = String(format: "%.2f %", quote.regularMarketChangePercent )
            //        "\(quote?.regularMarketChangePercent ?? 0)%"
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        performSegue(withIdentifier: "detailListing", sender: self)
        
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detailListing" {
            (segue.destination as? DetailListingViewController)?.results = results[tableView.indexPathForSelectedRow!.row]
            
        }
    }
    
}


