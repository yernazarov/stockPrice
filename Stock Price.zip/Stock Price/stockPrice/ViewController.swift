//
//  ViewController.swift
//  stockPrice
//
//  Created by Zhandos Yernazarov on 5/26/20.
//  Copyright © 2020 Zhandos Yernazarov. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

